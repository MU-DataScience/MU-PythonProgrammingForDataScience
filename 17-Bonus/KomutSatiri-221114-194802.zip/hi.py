
#########################################
# Komut Satırında Python Kodu Çalıştırma
#########################################

# GÖREV 1: PyCharm'da "hi.py" isminde python dosyası oluşturunuz.

# GÖREV 2: Bu dosyanın içirisine aşağıdaki kodu kendinize göre düzenleyerek ekleyiniz ve kaydediniz.
# print("Merhaba, ben isim soyisim!")

# GÖREV 3: Terminal üzerinden "hi.py" dosyasının olduğu dizine (klasöre) gidiniz. PyCharm’da sol tarafta
# yer alan menüde hi.py dosyası hangi klasördeyse o klasöre sağ tuş ile tıklayıp "open in > terminal” yaparak da olduğu
# dizine gidebilirsiniz. PyCharm'ın alt tarafında terminal ekranı açılacak. Şu an hi.py dosyası ile aynı dizindesiniz.

# GÖREV 4: Terminal’e  “python hi.py” yazarak , python kodunuzu çalıştırınız.

print("Merhaba, ben Simge Erek!")






